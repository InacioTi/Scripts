# keylogger
A simple Keylogger in Python 3.

Requires pynput:

<b>pip3 install pynput</b>

You need to set up the logFile variable to an appropriate location in your system:

logFile = "/home/fabio/python/keylogger/log.txt"

To run the script just type:

<b>python3 keylogger.py</b>

Code comments in Portuguese. 
